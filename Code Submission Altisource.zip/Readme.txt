Readme.txt
---------

This is a SpringBoot application that has a dependency on following libraries : 

hsql-db
spring-data-jpa
tomcat ( as web container ) 


Instructions to run: 

1. Import the .zip file as a maven project into eclipse 
2. Right Click POSAp and run as  "Spring Boot Application"
3. The context of the application is /pos



The Restful WebServices API are at the enpoints : 


ProductService
--------------
GET :  localhost:8080/pos/products


CartService
------------
GET :  localhost:8080/pos/
POST : localhost:8080/pos/
PUT :  localhost:8080/pos/{cart}
PUT :  localhost:8080/pos/{cart}/{product}
DELETE : localhost:8080/pos/{id}    ;   product-id


BillService
-------------
GET : localhost:8080/pos/bills
